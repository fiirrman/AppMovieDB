//
//  MovieReviewResponse.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation

struct MovieReviewResponse : Codable{
    let id : Int
    let page : Int
    let results : [MovieReviewResults]
}

struct MovieReviewResults : Codable{
    let author : String!
    let content : String!
    let updated_at : String!
    let url : String!
}


