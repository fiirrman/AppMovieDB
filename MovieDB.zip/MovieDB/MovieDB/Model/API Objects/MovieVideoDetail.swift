//
//  MovieVideoDetail.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation

struct MovieVideoDetail : Codable{
    let id : Int
    let results : [MovieVideoDetailResults]
}

struct MovieVideoDetailResults : Codable{
    let name : String!
    let key : String!
}



