//
//  ResponseStatus.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation

struct ResponseStatus : Codable{
    let status_code : String!
    let status_message : String!
    let success : Int
}
