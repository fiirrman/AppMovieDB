//
//  MovieList.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation

struct MovieListResponse : Codable {
    let page : Int
    let results : [MovieListResults]
}

struct MovieListResults : Codable{
    let id : Int
    let original_title : String!
    let poster_path : String!
    let backdrop_path : String!
    let release_date : String!
}
