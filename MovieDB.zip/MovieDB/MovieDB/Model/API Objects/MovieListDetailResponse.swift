//
//  MovieListDetailResponse.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation

struct MovieListDetailResponse : Codable{
    let genres : [MovieListDetailGenres]
    let original_title : String!
    let overview : String!
    let poster_path : String!
    let release_date : String!
}

struct MovieListDetailGenres : Codable{
    let id : Int
    let name : String!
}

