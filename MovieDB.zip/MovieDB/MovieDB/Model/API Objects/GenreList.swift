//
//  GenreList.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation

struct GenreList : Codable{
    let genres : [ArrGenreList]
}

struct ArrGenreList : Codable{
    let id : Int
    let name : String!
}
