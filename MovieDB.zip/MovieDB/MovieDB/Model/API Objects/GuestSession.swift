//
//  APISession.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation

struct GuestSessionResponse : Codable{
    let success : Bool
    let guest_session_id : String!
    let expires_at : String!
}
