//
//  DetailViewController.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import UIKit

class DetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    var idMovie = ""
    var idPlayer = ""
    var urlImagePoster = "-"
    var objDetail : MovieListDetailResponse?
    var arrGenre = [MovieListDetailGenres]()
    var stringGenre = ""
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Movie Detail"

        setTableView()
        callAPI(type: "loadData")
    }
    
    func setTableView(){
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: PhotoCell.identifier, bundle: nil), forCellReuseIdentifier: PhotoCell.identifier)
        tableView.register(UINib(nibName: TitleCell.identifier, bundle: nil), forCellReuseIdentifier: TitleCell.identifier)
    }
    
    func callAPI(type : String){
        view.addSubview(loadingBlock)
        if type == "loadVideo"{
            apiService.getMovieVideo(url: url_getMovieVideo + idMovie + "/videos" + apiKeyForm, completion: { [self] result,err  in
                if(result == nil){
                    self.showErrorAlert(errorMsg: err, isAction: false, title: "", typeAlert: "")
                }else{
                    idPlayer = Convert.toString(value: result?.results[0].key)
                    let vc = YoutubeViewController()
                    vc.idPlayer = idPlayer
                    navigatePage(typePage: vc)
                }
                
                loadingBlock.removeFromSuperview()
            })
        }else{
            apiService.getMovieDetail(url: url_getMovieDetail + idMovie + apiKeyForm, completion: { [self] result,err  in
                if(result == nil){
                    self.showErrorAlert(errorMsg: err, isAction: false, title: "", typeAlert: "")
                }else{
                    self.objDetail = result!
                    self.arrGenre = result!.genres
                }
                
                self.tableView.reloadData()
                loadingBlock.removeFromSuperview()
            })
        }
    }
    
    @objc func actionViewTrailer(){
        callAPI(type: "loadVideo")
    }
    
    @objc func actionViewReview(){
        let vc = mainStoryboard.instantiateViewController(identifier: "UserReviewViewController") as! UserReviewViewController
        vc.idMovie = idMovie
        vc.movieName = Convert.toString(value: objDetail?.original_title)
        navigatePage(typePage: vc)
    }
}

extension DetailViewController{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0{
            return 400
        }else if indexPath.row == 1{
            return UITableView.automaticDimension
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if(self.arrGenre.count > 0){
            if indexPath.row == 0{
                let cell = tableView.dequeueReusableCell(withIdentifier: PhotoCell.identifier, for: indexPath) as! PhotoCell
                if let posterUrl = self.objDetail?.poster_path{
                    downloadImage(url_image + posterUrl) { image in
                        if let image = image {
                            DispatchQueue.main.async {
                                cell.imageCell.image = image
                            }
                        }
                    }
                }else{
                    cell.imageCell.image = UIImage.init(named: "noImage")
                }
                return cell
            }else if indexPath.row == 1{
                let cell = tableView.dequeueReusableCell(withIdentifier: TitleCell.identifier, for: indexPath) as! TitleCell
                cell.labelTitle.text = objDetail?.original_title
                cell.labelDesc.text = objDetail?.overview

                for i in 0 ..< self.arrGenre.count{
                    if(i + 1 == self.arrGenre.count){
                        stringGenre = stringGenre + self.arrGenre[i].name
                    }else{
                        stringGenre = stringGenre + self.arrGenre[i].name + ", "
                    }
                }

                cell.labelGenre.text = stringGenre
                cell.labelRelease.text = objDetail?.release_date
                
                let tapTrailer = UITapGestureRecognizer(target: self, action: #selector(self.actionViewTrailer))
                cell.btnTrailer.addGestureRecognizer(tapTrailer)
                
                let tapReview = UITapGestureRecognizer(target: self, action: #selector(self.actionViewReview))
                cell.btnReview.addGestureRecognizer(tapReview)
                
                return cell
            }
        }
        
        return UITableViewCell()
    }
}
