//
//  YoutubeViewController.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import UIKit
import YoutubeKit

class YoutubeViewController: UIViewController, YTSwiftyPlayerDelegate {

    private var player: YTSwiftyPlayer!
    var idPlayer = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupPlayer()
    }
    
    func setupPlayer(){
        // Create a new player
        player = YTSwiftyPlayer(
                    frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight),
                    playerVars: [.videoID(idPlayer)])
        player.backgroundColor = .white
        // Enable auto playback when video is loaded
        player.autoplay = false
        // Set player view.
        view = player
        // Set delegate for detect callback information from the player.
        player.delegate = self
        // Load the video.
        player.loadPlayer()
    }
}

