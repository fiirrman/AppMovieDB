//
//  LoginViewController.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/6/21.
//

import UIKit

class LoginViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // MARK: ACTION VIEW
    @IBAction func actionGenerateGuestSession(_ sender: Any) {
        view.addSubview(loadingBlock)
        callAPI()
    }
    
    // MARK: API
    func callAPI(){
        apiService.sessionGenerate(url: url_authSession, param: [:], completion: { result,err  in
            self.showErrorAlert(errorMsg: "Success! Your session id is : \(Convert.toString(value: result?.guest_session_id)), expires at : \(Convert.toString(value: result?.expires_at))", isAction: true, title: "", typeAlert: "alertSessionCreate")
            // SAVE CRED
            self.credentialSave(val: Convert.toString(value: result?.guest_session_id), key: guestSessionKey, type: "save")
            loadingBlock.removeFromSuperview()
        })
    }
    
    // MARK: CALLBACK
    override func toHomePage() {
        // SET AS NAV CONTROLLER
        let vc = mainStoryboard.instantiateViewController(withIdentifier: "GenreViewController") as! GenreViewController
        let nc = UINavigationController(rootViewController: vc)
        appDelegate.window?.rootViewController = nc
        appDelegate.window?.makeKeyAndVisible()
    }
}
