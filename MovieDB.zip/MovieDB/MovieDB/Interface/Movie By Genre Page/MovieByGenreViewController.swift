//
//  MovieByGenreViewController.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import UIKit
import SkeletonView
import SDWebImage

class MovieByGenreViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var idGenre = ""
    var titleGenre = ""
    var arrMovieByGenre = [MovieListResults]()
    var refresh = UIRefreshControl()
    var page = 2
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.prefersLargeTitles = true
        title = "Genre : " + titleGenre
        
        setTableView()
        callAPI(type: "loadData")
    }
    
    func setTableView(){
        refresh.addTarget(self, action: #selector(requestMore), for: .valueChanged)
        if #available(iOS 10.0, *) {
            tableView.refreshControl = refresh
        } else {
            tableView.addSubview(refresh)
        }
        tableView.isSkeletonable = true
        tableView.showSkeleton(usingColor: .lightGray, transition: .crossDissolve(0.25))
        tableView.rowHeight = 70
        tableView.estimatedRowHeight = 70
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func callAPI(type : String){
        view.addSubview(loadingBlock)
        if(type == "loadData"){
            apiService.getMovieByGenre(url: url_getMovieByGenre + idGenre, completion: { result,err  in
                if(result == nil){
                    self.showErrorAlert(errorMsg: err, isAction: false, title: "", typeAlert: "")
                }else{
                    self.arrMovieByGenre = result!.results
                }
                
                self.tableView.reloadData()
                self.stopSkel()
                loadingBlock.removeFromSuperview()
            })
        }else if(type == "loadMoreData"){
            apiService.getMovieByGenre(url: url_getMovieByGenre + idGenre + "&page=\(page)", completion: { [self] result,err  in
                if(result == nil){
                    self.showErrorAlert(errorMsg: err, isAction: false, title: "", typeAlert: "")
                }else{
                    self.page = result!.page + 1
                    print("LATEST PAGE : \(page)")
                    self.arrMovieByGenre = self.arrMovieByGenre + result!.results
                }

                self.tableView.reloadData()
                self.stopSkel()
                loadingBlock.removeFromSuperview()
            })
        }
    }
    
    func stopSkel(){
        self.tableView.stopSkeletonAnimation()
        self.view.hideSkeleton(reloadDataAfter: true, transition: .crossDissolve(0.25))
    }
    
    @objc func requestMore(){
        tableView.reloadData()
        refresh.endRefreshing()
    }
    
    override func loadMoreMovies() {
        callAPI(type: "loadMoreData")
    }
}

extension MovieByGenreViewController : SkeletonTableViewDataSource, SkeletonTableViewDelegate{
    func collectionSkeletonView(_ skeletonView: UITableView, cellIdentifierForRowAt indexPath: IndexPath) -> ReusableCellIdentifier {
        return MovieByGenreCell.identifier
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        98
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrMovieByGenre.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieByGenreCell.identifier, for: indexPath) as! MovieByGenreCell
        cell.labelTitle.text = arrMovieByGenre[indexPath.row].original_title ?? "-"
        if let release = arrMovieByGenre[indexPath.row].release_date{
            cell.labelDesc.text = "Release Date : " + release
        }else{
            cell.labelDesc.text = "Release Date : -"
        }
        
        if let url = arrMovieByGenre[indexPath.row].backdrop_path{
            downloadImage(url_image + url) { image in
                if let image = image {
                    DispatchQueue.main.async {
                        cell.imageMovie.image = image
                    }
                }
            }
        }else{
            cell.imageMovie.image = UIImage.init(named: "noImage")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = mainStoryboard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.idMovie = Convert.toString(value: arrMovieByGenre[indexPath.row].id)
        navigatePage(typePage: vc)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row + 1 == arrMovieByGenre.count{
            if(page == 501){
                showErrorAlert(errorMsg: "Maximum Page Reached", isAction: false, title: "", typeAlert: "")
            }else{
                spinnerTable.startAnimating()
                spinnerTable.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: tableView.bounds.width, height: CGFloat(44))

                tableView.tableFooterView = spinnerTable
                tableView.tableFooterView?.isHidden = false
                
                showErrorAlert(errorMsg: "Load More?", isAction: true, title: "", typeAlert: "alertLoadMoreMovies")
            }
        }
    }
}

