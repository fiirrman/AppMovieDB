//
//  UserReviewViewController.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import UIKit
import SkeletonView

class UserReviewViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet weak var tableReview: UITableView!
    
    var idMovie = ""
    var movieName = ""
    var refreshTable = UIRefreshControl()
    var page = 1
    var arrResultReview = [MovieReviewResults]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.prefersLargeTitles = true
        title = "Review List"
        
        setTableView()
        callAPI(type: "loadData")
    }
    
    func setTableView(){
        tableReview.delegate = self
        tableReview.dataSource = self
        tableReview.tableFooterView = UIView()
    }
    
    func callAPI(type : String){
        view.addSubview(loadingBlock)
        if(type == "loadData"){
            apiService.getMovieReviewUser(url: url_getMovieDetail + idMovie + "/reviews\(apiKeyForm)&page=1", completion: { result,err  in
                if(result == nil){
                    self.showErrorAlert(errorMsg: err, isAction: false, title: "", typeAlert: "")
                }else{
                    self.page = result!.page
                    self.arrResultReview = result!.results
                }

                self.tableReview.reloadData()
                loadingBlock.removeFromSuperview()
            })
        }else if(type == "loadMoreData"){
            apiService.getMovieReviewUser(url: url_getMovieDetail + idMovie + "/reviews\(apiKeyForm)&page=\(page + 1)", completion: { result,err  in
                if(result == nil){
                    self.showErrorAlert(errorMsg: err, isAction: false, title: "", typeAlert: "")
                }else{
                    self.page = self.page + 1
                    self.arrResultReview = self.arrResultReview + result!.results
                    
                    if(result!.results.count == 0){
                        self.showErrorAlert(errorMsg: "Maximum Page Reached", isAction: false, title: "", typeAlert: "")
                        spinnerTable.stopAnimating()
                    }else{
                        self.tableReview.reloadData()
                    }
                }
                loadingBlock.removeFromSuperview()
            })
        }
    }
    
    override func loadMoreReview() {
        callAPI(type: "loadMoreData")
    }
}

extension UserReviewViewController{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.arrResultReview.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UserReviewCell.identifier, for: indexPath) as! UserReviewCell
        if self.arrResultReview.count > 0 {
            cell.labelAuthor.text = "Author : " + arrResultReview[indexPath.row].author
            cell.labelUpdate.text = arrResultReview[indexPath.row].updated_at
            cell.labelReview.text = arrResultReview[indexPath.row].content
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row + 1 == arrResultReview.count{
            spinnerTable.startAnimating()
            spinnerTable.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: tableView.bounds.width, height: CGFloat(44))

            tableView.tableFooterView = spinnerTable
            tableView.tableFooterView?.isHidden = false

            showErrorAlert(errorMsg: "Load More?", isAction: true, title: "", typeAlert: "alertLoadMoreReview")
        }
    }
}
