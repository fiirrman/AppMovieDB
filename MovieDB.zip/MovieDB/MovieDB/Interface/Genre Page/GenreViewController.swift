//
//  GenreViewController.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/6/21.
//

import UIKit
import SkeletonView

class GenreViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var arrGenre = [ArrGenreList]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.prefersLargeTitles = true
        title = "Movie Genre List"
        
        setTableView()
        callAPI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func setTableView(){
        tableView.isSkeletonable = true
        tableView.showAnimatedGradientSkeleton(usingGradient: .init(baseColor: .lightGray), animation: nil, transition: .crossDissolve(0.25))
        tableView.rowHeight = 70
        tableView.estimatedRowHeight = 70
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func callAPI(){
        view.addSubview(loadingBlock)
        apiService.getGenreList(url: url_getListGenre, completion: { result,err  in
            if(result == nil){
                self.showErrorAlert(errorMsg: err, isAction: false, title: "", typeAlert: "")
            }else{
                self.arrGenre = result!.genres
            }
            self.tableView.reloadData()
            self.stopSkel()
            loadingBlock.removeFromSuperview()
        })
    }
    
    func stopSkel(){
        self.tableView.stopSkeletonAnimation()
        self.view.hideSkeleton(reloadDataAfter: true, transition: .crossDissolve(0.25))
    }
}

extension GenreViewController : SkeletonTableViewDataSource, SkeletonTableViewDelegate{
    func collectionSkeletonView(_ skeletonView: UITableView, cellIdentifierForRowAt indexPath: IndexPath) -> ReusableCellIdentifier {
        return GenreCell.identifier
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        70
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrGenre.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: GenreCell.identifier, for: indexPath) as! GenreCell
        if(arrGenre.count > 0){
            cell.labelTitle.text = arrGenre[indexPath.row].name
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = mainStoryboard.instantiateViewController(withIdentifier: "MovieByGenreViewController") as! MovieByGenreViewController
        vc.idGenre = Convert.toString(value: arrGenre[indexPath.row].id)
        vc.titleGenre = arrGenre[indexPath.row].name
        navigatePage(typePage: vc)
    }
}
