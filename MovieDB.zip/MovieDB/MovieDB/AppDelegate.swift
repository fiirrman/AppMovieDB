//
//  AppDelegate.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/6/21.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        self.window = UIWindow.init(frame: UIScreen.main.bounds)

        let vc = mainStoryboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.window!.rootViewController = vc

        // CHECK IS LOGIN
        if let valueGuest = userDefaults.value(forKey: guestSessionKey) as? String{
            if valueGuest != ""{
                print("GUEST SESSION ID : \(valueGuest)")
                let vc2 = mainStoryboard.instantiateViewController(withIdentifier: "GenreViewController") as! GenreViewController
                let nc = UINavigationController(rootViewController: vc2)
                self.window!.rootViewController = nc
            }
        }

        self.window?.makeKeyAndVisible()

        return true
    }
}

