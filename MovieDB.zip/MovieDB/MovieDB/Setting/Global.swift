//
//  Global.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/6/21.
//

import UIKit

// MARK: CONSTANT
let screenSize = UIScreen.main.bounds
let screenWidth = screenSize.width
let screenHeight = screenSize.height
var loadingBlock = Create.indicator(blocking: true) // LOADING VIEW
var mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
let appDelegate = UIApplication.shared.delegate as! AppDelegate
let userDefaults = UserDefaults()
let apiService = APIManager.init()
let spinnerTable = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.medium)

// MARK: API
let apiKey = "0d062fd54ed6262ae8abb99286795ebf"
let apiKeyForm = "?api_key=0d062fd54ed6262ae8abb99286795ebf&language=en-US"
let url_image = "https://image.tmdb.org/t/p/w500/"
let url_main = "https://api.themoviedb.org/3/"
let url_authSession = url_main + "authentication/guest_session/new?api_key=" + apiKey
let url_deleteSession = url_main + "authentication/session?api_key=" + apiKey
let url_getListGenre = url_main + "genre/movie/list?api_key=" + apiKey + "&language=en-US"
let url_getMovieByGenre = url_main + "discover/movie?api_key=" + apiKey + "&language=en-US" + "&with_genres="
let url_getMovieDetail = url_main + "movie/"
let url_getMovieVideo = url_main + "movie/"

// MARK: KEY
let guestSessionKey = "guestSessionKey"

// MARK: EXT UIVIEWCONTROLLER
extension UIViewController{
    // LOADING
    func loading(blocking : Bool) -> UIView {
        let indicatorView:UIActivityIndicatorView = UIActivityIndicatorView(style:UIActivityIndicatorView.Style.whiteLarge);
        indicatorView.frame.origin.x = screenWidth/2-indicatorView.frame.size.width/2;
        indicatorView.startAnimating();
        indicatorView.layer.cornerRadius=10.0;
        indicatorView.frame.size.width = indicatorView.frame.size.width*2;
        indicatorView.frame.size.height = indicatorView.frame.size.height*2;
        indicatorView.backgroundColor = UIColor.black.withAlphaComponent(0.7);
        indicatorView.center.x = screenWidth/2;
        indicatorView.center.y = screenHeight/2;
        if(blocking) {
            let view:UIView = UIView(frame:CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight));
            view.backgroundColor=UIColor.clear;
            view.addSubview(indicatorView);
            return view;
        }
        else {
            return indicatorView;
        }
    }
    
    // SHOW ALERT ===========
    func showErrorAlert(errorMsg : String, isAction : Bool, title : String, typeAlert : String){
        let msg = title
        let ac = UIAlertController(title: msg, message: errorMsg, preferredStyle: .alert)
        if(isAction){
            let stringOK = "OK"
            
            // Create the actions
            let okAction = UIAlertAction(title: stringOK, style: UIAlertAction.Style.default) {
                UIAlertAction in
                if(typeAlert == "alertSessionCreate"){
                    self.toHomePage()
                }else if(typeAlert == "alertLoadMoreMovies"){
                    self.loadMoreMovies()
                }else if(typeAlert == "alertLoadMoreReview"){
                    self.loadMoreReview()
                }
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
                UIAlertAction in
                if(typeAlert == "alertLoadMoreMovies" || typeAlert == "alertLoadMoreReview"){
                    spinnerTable.stopAnimating()
                }else{
                    self.noFunction()
                }
                NSLog("Cancel Pressed")
            }
            
            ac.addAction(okAction)
            if(typeAlert != "alertSessionCreate"){
                ac.addAction(cancelAction)
            }
        }else{
            ac.addAction(UIAlertAction(title: "OK", style: .default))
        }
        
        self.present(ac, animated:  true)
    }
    
    func noFunction(){}
    @objc func toHomePage(){}
    @objc func loadMoreMovies(){}
    @objc func loadMoreReview(){}
    
    // NAVIGATE PAGE
    func navigatePage(typePage : UIViewController){
        let newViewController = typePage
        self.navigationController?.pushViewController(newViewController, animated: true)
    }
    
    func credentialSave(val : String, key : String, type : String){
        if(type == "save"){
            userDefaults.setValue(val, forKey: key)
        }else{
            userDefaults.value(forKey: key)
        }
    }
    
    // DOWNLOAD IMAGE ============
    func downloadImage(_ link: String?, linkwithCompletion completion: @escaping (UIImage?)->()) {
        guard let url = try? link?.asURL() else { // SWIFT 5
            completion(nil)
            return
        }
        let imageURL = url
        
        let task = URLSession.shared.dataTask(with: imageURL) { (data, responce, _) in
            if let data = data, let image = UIImage(data: data) {
                completion(image)
            }else{
                completion(UIImage.init(named: "image"))
            }
        }
        task.resume()
    }
}

// MARK: STRUCT
struct Create {
    static func indicator(blocking:Bool) -> UIView {
        let indicatorView:UIActivityIndicatorView = UIActivityIndicatorView(style:UIActivityIndicatorView.Style.whiteLarge);
        indicatorView.frame.origin.x = screenWidth/2-indicatorView.frame.size.width/2;
        indicatorView.startAnimating();
        indicatorView.layer.cornerRadius=10.0;
        indicatorView.frame.size.width = indicatorView.frame.size.width*2;
        indicatorView.frame.size.height = indicatorView.frame.size.height*2;
        indicatorView.backgroundColor = UIColor.black.withAlphaComponent(0.7);
        indicatorView.center.x = screenWidth/2;
        indicatorView.center.y = screenHeight/2;
        if(blocking) {
            let view:UIView = UIView(frame:CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight));
            view.backgroundColor=UIColor.clear;
            view.addSubview(indicatorView);
            return view;
        }
        else {
            return indicatorView;
        }
    }
    
    static func indicatorWithButton(blocking : Bool, viewC : UIViewController) -> UIView {
        let alert = UIAlertController(title: "", message:"loading..", preferredStyle: .alert);

        let loadingIndicator: UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRect(x: 50, y: 10, width: 37, height: 37)) as UIActivityIndicatorView
        loadingIndicator.center = viewC.view.center
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.medium
        loadingIndicator.startAnimating();

        alert.setValue(loadingIndicator, forKey: "accessoryView")
        loadingIndicator.startAnimating()

        viewC.present(alert, animated: true, completion: nil)
        
        return UIView()
    }
}

// CONVERT ANY
struct Convert {
    static func toString(value:Any?) -> String {
        var string:String="";
        if let y = value as? String {
            string = y;
        }
        else if let y = value as? Int {
            string = String(y);
        }
        return string;
    }
}


