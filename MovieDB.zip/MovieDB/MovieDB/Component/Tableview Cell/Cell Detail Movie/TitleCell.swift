//
//  TitleCell.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import UIKit

class TitleCell: UITableViewCell {
    
    static let identifier = "TitleCell"
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDesc: UILabel!
    @IBOutlet weak var labelGenre: UILabel!
    @IBOutlet weak var labelRelease: UILabel!
    @IBOutlet weak var labelRating: UILabel!
    @IBOutlet weak var btnTrailer: UIButton!
    @IBOutlet weak var btnReview: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
