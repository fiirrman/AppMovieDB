//
//  UserReviewCell.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import UIKit

class UserReviewCell: UITableViewCell {

    static var identifier = "UserReviewCell"
    
    @IBOutlet weak var labelAuthor: UILabel!
    @IBOutlet weak var labelUpdate: UILabel!
    @IBOutlet weak var labelReview: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
