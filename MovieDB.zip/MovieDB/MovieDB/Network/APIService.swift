//
//  APIService.swift
//  MovieDB
//
//  Created by Firman Aminuddin on 6/7/21.
//

import Foundation
import Alamofire

protocol APIManagerDelegate {
}

class APIManager: APIManagerDelegate {
    
    func sessionGenerate(url : String, param : Parameters, completion: @escaping ((GuestSessionResponse?, String) -> ())){
        AF.request(url, method: .post, parameters: param, encoding: JSONEncoding.default, headers: nil)
            .responseJSON { response in
                print("REQUEST API: \(String(describing: response.request))")
                print("RESULT API: \(response.result)")
                if response.error == nil {
                    guard let data = response.data else { return }
                    do {
                        let dataResponse = try JSONDecoder().decode(GuestSessionResponse.self, from: data)
                        completion(dataResponse, "")
                    } catch {
                        if let result = response.value {
                            let JSON = result as! NSDictionary
                            let msg = JSON["status_message"] as! String
                            let code = JSON["status_code"] as! Int
                            completion(nil, "Error Code : \(code), Description : \(msg)")
                        }else{
                            completion(nil, response.error!.localizedDescription)
                        }
                    }
                } else {
                    completion(nil, response.error!.localizedDescription)
                }
        }
    }
    
    func getGenreList(url : String, completion: @escaping ((GenreList?, String) -> ())){
        AF.request(url, method: .get, encoding: JSONEncoding.default, headers: nil)
            .responseJSON { response in
                print("REQUEST API: \(String(describing: response.request))")
                print("RESULT API: \(response.result)")
                if response.error == nil {
                    guard let data = response.data else { return }
                    do {
                        let decoder = JSONDecoder()
                        let dataResponse = try decoder.decode(GenreList.self, from: data)
                        completion(dataResponse, "")
                    } catch {
                        if let result = response.value {
                            let JSON = result as! NSDictionary
                            let msg = JSON["status_message"] as! String
                            let code = JSON["status_code"] as! Int
                            completion(nil, "Error Code : \(code), Description : \(msg)")
                        }else{
                            completion(nil, response.error!.localizedDescription)
                        }
                    }
                } else {
                    completion(nil, response.error!.localizedDescription)
                }
        }
    }
    
    func getMovieByGenre(url : String, completion: @escaping ((MovieListResponse?, String) -> ())){
        AF.request(url, method: .get, encoding: JSONEncoding.default, headers: nil)
            .responseJSON { response in
                print("REQUEST API: \(String(describing: response.request))")
                print("RESULT API: \(response.result)")
                if response.error == nil {
                    guard let data = response.data else { return }
                    do {
                        let decoder = JSONDecoder()
                        let dataResponse = try decoder.decode(MovieListResponse.self, from: data)
                        completion(dataResponse, "")
                    } catch {
                        if let result = response.value {
                            let JSON = result as! NSDictionary
                            let msg = JSON["status_message"] as! String
                            let code = JSON["status_code"] as! Int
                            completion(nil, "Error Code : \(code), Description : \(msg)")
                        }else{
                            completion(nil, response.error!.localizedDescription)
                        }
                    }
                } else {
                    completion(nil, response.error!.localizedDescription)
                }
        }
    }
    
    func getMovieDetail(url : String, completion: @escaping ((MovieListDetailResponse?, String) -> ())){
        AF.request(url, method: .get, encoding: JSONEncoding.default, headers: nil)
            .responseJSON { response in
                print("REQUEST API: \(String(describing: response.request))")
                print("RESULT API: \(response.result)")
                if response.error == nil {
                    guard let data = response.data else { return }
                    do {
                        let decoder = JSONDecoder()
                        let dataResponse = try decoder.decode(MovieListDetailResponse.self, from: data)
                        completion(dataResponse, "")
                    } catch {
                        if let result = response.value {
                            let JSON = result as! NSDictionary
                            let msg = JSON["status_message"] as! String
                            let code = JSON["status_code"] as! Int
                            completion(nil, "Error Code : \(code), Description : \(msg)")
                        }else{
                            completion(nil, response.error!.localizedDescription)
                        }
                    }
                } else {
                    completion(nil, response.error!.localizedDescription)
                }
        }
    }
    
    func getMovieVideo(url : String, completion: @escaping ((MovieVideoDetail?, String) -> ())){
        AF.request(url, method: .get, encoding: JSONEncoding.default, headers: nil)
            .responseJSON { response in
                print("REQUEST API: \(String(describing: response.request))")
                print("RESULT API: \(response.result)")
                if response.error == nil {
                    guard let data = response.data else { return }
                    do {
                        let decoder = JSONDecoder()
                        let dataResponse = try decoder.decode(MovieVideoDetail.self, from: data)
                        completion(dataResponse, "")
                    } catch {
                        if let result = response.value {
                            let JSON = result as! NSDictionary
                            let msg = JSON["status_message"] as! String
                            let code = JSON["status_code"] as! Int
                            completion(nil, "Error Code : \(code), Description : \(msg)")
                        }else{
                            completion(nil, response.error!.localizedDescription)
                        }
                    }
                } else {
                    completion(nil, response.error!.localizedDescription)
                }
        }
    }
    
    func getMovieReviewUser(url : String, completion: @escaping ((MovieReviewResponse?, String) -> ())){
        AF.request(url, method: .get, encoding: JSONEncoding.default, headers: nil)
            .responseJSON { response in
                print("REQUEST API: \(String(describing: response.request))")
                print("RESULT API: \(response.result)")
                if response.error == nil {
                    guard let data = response.data else { return }
                    do {
                        let decoder = JSONDecoder()
                        let dataResponse = try decoder.decode(MovieReviewResponse.self, from: data)
                        completion(dataResponse, "")
                    } catch {
                        if let result = response.value {
                            let JSON = result as! NSDictionary
                            let msg = JSON["status_message"] as! String
                            let code = JSON["status_code"] as! Int
                            completion(nil, "Error Code : \(code), Description : \(msg)")
                        }else{
                            completion(nil, response.error!.localizedDescription)
                        }
                    }
                } else {
                    completion(nil, response.error!.localizedDescription)
                }
        }
    }
}
